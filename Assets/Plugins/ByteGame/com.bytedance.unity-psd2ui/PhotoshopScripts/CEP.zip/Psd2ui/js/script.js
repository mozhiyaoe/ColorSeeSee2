﻿var cs = new CSInterface();

var exampleRoot=cs.getSystemPath(SystemPath.EXTENSION)+"/Example/";
//var bPSCallBackEnable = true;

function CallEvalScript(scriptString,callback)
{
    //bPSCallBackEnable = false;
    
    try
    {
        cs.evalScript(scriptString,callback);
    }
    catch (e) 
    { 
        alert(e);
    }
    //bPSCallBackEnable = true;
}

function CreateFromTemplate(templateName)
{
    CallEvalScript("CreateFromTemplate('" + exampleRoot + templateName + "')"); 
}

function crtButton()
{
    CreateFromTemplate("Button");   
}

function crtImage()
{
    CreateFromTemplate("Image");   
}

function crtSlider()
{
    CreateFromTemplate("Slider");   
}

function crtToggle()
{    
    CreateFromTemplate("Toggle");   
}

function crtScrollview()
{
    CreateFromTemplate("ScrollView");   
}

function crtDropdown()
{    
    CreateFromTemplate("DropDown");   
}

function crtrawImage()
{     
    CreateFromTemplate("RawImage");   
}

function crtInputfield()
{    
    CreateFromTemplate("InputField");   
}

function crtPannel()
{    
    CallEvalScript("CreateComponent('Group')");   
}

function crtText()
{    
    CreateFromTemplate("Text");  
}

function flattenPSD()
{
	CallEvalScript("FlattenPSD()");  
}

function OnCreateCanvas()
{
    var cavwidth=document.getElementById("field1").value;
    var canvheight=document.getElementById("field2").value;
    var canvname=document.getElementById("field3").value;  
    canvArray="crtCanvas("+cavwidth+","+canvheight+","+"\""+canvname+"\""+")";
    CallEvalScript(canvArray);  
}

function crtCanvasClick ()
{
        dialog.showModal();
}

function crtTemplate()
{
    CallEvalScript("CreateTemplate()");
}

function refreshTemplate()
{
    CallEvalScript("RefreshTemplate()");
}

function importImage()
{
    CallEvalScript("ImportImage()");
}

function onShowBoundsClick()
{
    CallEvalScript("ShowBounds()");
}

function onRenameClick()
{
    CallEvalScript('GetSelectedName()',onRenameClickCallback);
    
    rename.showModal();
}

function onRenameClickCallback(name) {
	document.getElementById("renameText").value = name;
}

function RefreshName()
{
    CallEvalScript('GetSelectedName()',OnRefreshName);
}

function OnRefreshName(name) 
{
	document.getElementById("ObjectName").innerHTML = name;
}

function RefreshType()
{
    CallEvalScript('GetSelectedType()',OnRefreshType);
}

function OnRefreshType(type) 
{
	document.getElementById("ObjectType").innerHTML = type;
}

function RefreshSrcImg()
{
    CallEvalScript('GetSelectedSrcImg()',OnRefreshSrcImg);
}

function OnRefreshSrcImg(srcimg) 
{
    if(srcimg == "")
        document.getElementById("ObjectSrcImg").style.display = "none";
    else
    {
        document.getElementById("ObjectSrcImg").innerHTML = "srcimg:"+srcimg;
        document.getElementById("ObjectSrcImg").style.display = "inline";
    }
}

function onImageTypeChanged()
{
    var imgtype = document.getElementById("ObjectImgType").value;
    CallEvalScript("ChangeImageType('"+imgtype+"')"); 
}

function RefreshImgType()
{
    CallEvalScript('GetImgType()',OnGetImgType);
}

function OnGetImgType(type)
{
    if(type == "")
    {
         document.getElementById("ObjectImgType").style.display = "none";
         document.getElementById("ImgTypeTitle").style.display = "none";
    }
    else
    {
        document.getElementById("ObjectImgType").style.display = "inline";
        document.getElementById("ImgTypeTitle").style.display = "inline";
        document.getElementById("ObjectImgType").value = type;
    }
}

function RefreshAnchorImg()
{
    CallEvalScript('GetAnchorImg()',OnGetAnchorImg);
}

function OnGetAnchorImg(img)
{
    var anchorImg = document.getElementById("AnchorImg");
    anchorImg.src = "img/"+ img + ".png";
}

function RefreshPivotImg()
{
    CallEvalScript('GetPivotImg()',OnGetPivotImg);
}

function OnGetPivotImg(img)
{
    var pivotImg = document.getElementById("PivotImg");
    pivotImg.src = "img/"+ img + ".png";
}

function OnRename()
{
    var name = document.getElementById("renameText").value;
    CallEvalScript("SetSelectedName('" +name +"')");
    
    RefreshName();
}

function LeftAnchor()
{
    CallEvalScript('LeftAnchor()'); 
}

function RightAnchor()
{
    CallEvalScript('RightAnchor()'); 
}

function CenterAnchor()
{
    CallEvalScript('CenterAnchor()'); 
}
function HStretchAnchor()
{
   CallEvalScript('HStretchAnchor()'); 
}

function TopAnchor()
{
    CallEvalScript('TopAnchor()'); 
}

function BottomAnchor()
{
    CallEvalScript('BottomAnchor()'); 
}

function MiddleAnchor()
{
    CallEvalScript('MiddleAnchor()'); 
}
function VStretchAnchor()
{
    CallEvalScript('VStretchAnchor()'); 
}

function LeftPivot()
{
    CallEvalScript('LeftPivot()'); 
}

function RightPivot()
{
    CallEvalScript('RightPivot()'); 
}

function CenterPivot()
{
    CallEvalScript('CenterPivot()'); 
}

function TopPivot()
{
    CallEvalScript('TopPivot()'); 
}

function BottomPivot()
{
    CallEvalScript('BottomPivot()'); 
}

function MiddlePivot()
{
    CallEvalScript('MiddlePivot()'); 
}


//Event dispatch
var event = new CSEvent();
event.type = "com.adobe.PhotoshopRegisterEvent";
event.scope = "APPLICATION";
event.data = "1936483188,1147958304,1936028772,1148415075,1836021349,1147958304,1298866208,1148218467";
//event.data = "1097624608";
event.extensionId = cs.getExtensionID();

var cs = new CSInterface();
cs.dispatchEvent(event);

cs.addEventListener("com.adobe.PhotoshopJSONCallback" + cs.getExtensionID(), PSCallback);

cs.addEventListener("documentAfterActivate" , OnDocumentAfterActivate); //applicationActivate : 文档被激活

function OnDocumentAfterActivate(event) //处理事件的函数，会接受到一个 Event 对象
{
    CallEvalScript('UpdateSelection()'); 
    UpdateProperties();
}

function OnNameChanged(event)
{
    if(event.keyCode == 13)
    {
        OnRename();
    }
}


function OnCanvasChanged(event)
{
    if(event.keyCode == 13)
    {
        OnCreateCanvas();
    }
}

function PSCallback(csEvent)
{
   /* if(!bPSCallBackEnable)
        return;*/
    
    //console.log(csEvent.data);
    var eventData = csEvent.data.replace("ver1,{", "{");
    crtEventCheck(eventData);
}

function crtEventCheck(eventdata)
{ 
    CallEvalScript("crtEventCheck('" + eventdata + "')");  
    UpdateProperties();
}

function UpdateProperties()
{
    RefreshAnchorImg();
    RefreshPivotImg();
    RefreshName();
    RefreshType();
    RefreshSrcImg();
    RefreshImgType();
}

UpdateProperties();




